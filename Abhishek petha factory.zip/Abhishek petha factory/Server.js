require('dotenv').config();
const express = require('express');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json()); // for JSON POSTs

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// 1) Create order endpoint (frontend calls this during checkout)
app.post('/api/create-order', async (req, res) => {
  try {
    // expected: { amount, currency, items, shippingAddress, userId }
    const { amount, currency = 'INR', items, shippingAddress, userId } = req.body;

    // validate items, check stock, compute total on server (do not trust client)
    // amount should be in paise for INR, e.g., Rs.100 => 10000
    const options = {
      amount: amount, // amount in paise (integer)
      currency,
      receipt: 'rcpt_' + Date.now(),
      payment_capture: 1 // 1 => automatic capture; 0 => manual capture
    };

    const order = await razorpay.orders.create(options);

    // Save order record in your DB with status 'created', store razorpay_order_id
    // Example (pseudo):
    // const dbOrder = await Order.create({ userId, amount, currency, status:'created', razorpay_order_id: order.id, shipping_address: JSON.stringify(shippingAddress) });
    // return order details to client
    res.json({ success: true, order });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Server error' });
  }
});