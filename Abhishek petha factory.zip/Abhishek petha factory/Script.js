// basic interactivity: mobile nav toggle, year update, simple contact form handling, cart demo
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('site-nav');

  toggle?.addEventListener('click', () => {
    if (!nav) return;
    nav.style.display = (nav.style.display === 'block') ? 'none' : 'block';
  });

  // Set current year
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Contact form handler (demo only)
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Thanks! Your message has been received. (This form is a demo — connect to a server to process messages.)');
      form.reset();
    });
  }

  // Add-to-cart demo
  document.querySelectorAll('.add-cart').forEach(btn => {
    btn.addEventListener('click', () => {
      const name = btn.getAttribute('data-name');
      const price = btn.getAttribute('data-price');
      alert(`${name} added to cart — ₹${price} (demo). Implement cart & checkout with backend/payment gateway.`);
    });
  });
});